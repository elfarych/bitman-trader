function testClick () {
    console.log('click')
    wallet.scan()
}

const wallet = new Wallet()

